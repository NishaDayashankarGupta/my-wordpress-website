<?php
/**
 * Template part for displaying ajax search products loop end.
 * 
 * This template can be overridden by copying it to yourtheme/template-parts/search/content-ajax-search-loop-end.php.
 *
 * HOWEVER, on occasion Botiga will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 *
 * @package Botiga\Templates
 * @version 2.2.4
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>

</div>