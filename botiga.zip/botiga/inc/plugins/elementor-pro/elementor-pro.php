<?php
/**
 * Elementor Pro Compatibility File
 *
 * @package Botiga
 */

require_once get_template_directory() . '/inc/plugins/elementor-pro/class-botiga-elementor-pro-widgets.php';